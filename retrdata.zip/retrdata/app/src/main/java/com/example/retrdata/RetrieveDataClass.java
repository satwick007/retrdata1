package com.example.retrdata;

import android.widget.TextView;

public class RetrieveDataClass {
    String RUNTIME,SPECIFICPOWER,UNITS;
    public RetrieveDataClass(){}

    public RetrieveDataClass(String RUNTIME) {
        this.RUNTIME = RUNTIME;
        this.SPECIFICPOWER = SPECIFICPOWER;
        this.UNITS = UNITS;
    }

    public String getRUNTIME() {
        return RUNTIME;
    }

    public void setRUNTIME(String RUNTIME) {
        this.RUNTIME = RUNTIME;
    }

    public String getSPECIFICPOWER() {
        return SPECIFICPOWER;
    }

    public void setSPECIFICPOWER(String SPECIFICPOWER) {
        this.SPECIFICPOWER = SPECIFICPOWER;
    }

    public String getUNITS() {
        return UNITS;
    }

    public void setUNITS(String UNITS) {
        this.UNITS = UNITS;
    }
}
